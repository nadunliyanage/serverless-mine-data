using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWSServerless2
{
    public class MineData
    {
        public string Guid { get; set; }
        public DateTime CreatedTimestamp { get; set; }
    }
}
